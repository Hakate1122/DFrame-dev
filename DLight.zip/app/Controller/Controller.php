<?php

declare(strict_types=1);

namespace App\Controller;

use DLight\Application\View;
use \Exception;

class Controller
{
    /**
     * Render view with data.
     * @param string $view View name to render (directory at: resource/view/)
     * @param array $data Data to pass to the view
     * @throws Exception if view file not found
     * @return void (echoes the rendered view)
     */
    public function render(string $view, array $data = [])
    {
        $viewObj = new View();
        echo $viewObj->view($view, $data);
    }
}
