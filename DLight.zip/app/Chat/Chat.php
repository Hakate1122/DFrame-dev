<?php
namespace App\Chat;

use DLight\Application\WebSocket;

class Chat extends WebSocket{
    protected function onOpen(\Socket $client): void
    {
        $this->sendMessageToAll("A user has joined the chat.");
    }

    protected function onClose(\Socket $client): void
    {
        $this->sendMessageToAll("A user has left the chat.");
    }

    protected function onMessage(\Socket $client, string $message): void
    {
        $this->sendMessageToAll($message, $client);
    }

    private function sendMessageToAll(string $message, ?\Socket $excludeClient = null): void
    {
        $excludeId = $excludeClient instanceof \Socket ? spl_object_id($excludeClient) : null;

        foreach ($this->clients as $client) {
            $clientId = spl_object_id($client);
            if ($excludeId !== null && $clientId === $excludeId) {
                $this->send($client, "You: $message");
            } else {
                $this->send($client, $message);
            }
        }
    }
}