<?php

namespace DLight\Database\Traits;

/**
 * **SoftDelete Trait**
 *
 * This trait provides functionality to mark an object as deleted without actually removing it from the database.
 * 
 * It allows for soft deletion and restoration of the object.
 */
trait SoftDelete
{
    protected function checkColumns()
    {
        $adapter = $this->adapter ?? ($this->db ?? null);
        $table = $this->table ?? null;
        if (!$adapter || !$table) {
            throw new \RuntimeException("SoftDelete: Adapter or table not set in model.");
        }

        $adapterClass = $adapter::class;
        if (stripos($adapterClass, 'sqlite') !== false) {
            $sql = "PRAGMA table_info(\"{$table}\")";
            $res = $adapter->query($sql);
            $rows = $adapter->fetchAll($res);
            foreach ($rows as $r) {
                $name = $r['name'] ?? $r['Name'] ?? null;
                $type = strtolower($r['type'] ?? '');
                $nullable = !($r['notnull'] ?? 1);
                if ($name === 'deleted_at') {
                    if (!str_contains($type, 'date') && !str_contains($type, 'time')) {
                        throw new \RuntimeException("SoftDelete: 'deleted_at' column must be DATETIME or TIMESTAMP, got '$type'");
                    }
                    if (!$nullable) {
                        throw new \RuntimeException("SoftDelete: 'deleted_at' column must be nullable.");
                    }
                    return true;
                }
            }
        } else {
            $sql = "SHOW COLUMNS FROM `{$table}` LIKE 'deleted_at'";
            $res = $adapter->query($sql);
            $rows = $adapter->fetchAll($res);
            if (!empty($rows)) {
                $row = $rows[0];
                $type = strtolower($row['Type'] ?? '');
                $nullable = strtolower($row['Null'] ?? '') === 'yes';
                if (!str_contains($type, 'date') && !str_contains($type, 'time')) {
                    throw new \RuntimeException("SoftDelete: 'deleted_at' column must be DATETIME or TIMESTAMP, got '$type'");
                }
                if (!$nullable) {
                    throw new \RuntimeException("SoftDelete: 'deleted_at' column must be nullable.");
                }
                return true;
            }
        }
        throw new \RuntimeException("SoftDelete: 'deleted_at' column not found in table '{$table}'.");
    }

    /**
     * The timestamp when the object was soft deleted
     *
     * @var string|null
     */
    public function softDelete()
    {
        $this->checkColumns();
        if ($this->isDeleted()) {
            return false;
        }
        $this->deleted_at = date('Y-m-d H:i:s');
        return $this->save();
    }
    /**
     * Restore the object from soft deletion
     *
     * @return bool
     */
    public function restore()
    {
        $this->checkColumns();
        if (!$this->isDeleted()) {
            return false;
        }
        $this->deleted_at = null;
        return $this->save();
    }
    /**
     * Check if the object is soft deleted
     *
     * @return bool
     */
    public function isDeleted()
    {
        return $this->deleted_at !== null;
    }
}